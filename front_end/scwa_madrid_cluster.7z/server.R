
library(shiny)
library(dplyr)
library(ggmap)
library(readr)
library (leaflet)


scwa <- read_csv("scwa.csv")


shinyServer(function(input, output) {
  
  factpal <- topo.colors(7,alpha = 1)
  
  output$coolmap <- renderLeaflet({
    
    
    leaflet(data=scwa) %>% addTiles() %>% addCircleMarkers(lng = ~lon,lat =  ~lat, color= "blue", 
                                                     label= paste("Consumo: ", scwa$Consumo_anual, "[m3] ", "_Tipo de consumidor: ", scwa$Tipo_consumidor), clusterOptions = markerClusterOptions()) %>% 
      addLegend("bottomright", colors = factpal, labels = unique(scwa$Tipo_consumidor), title = "Tipo de consumidor" )
     
  })
 })


