#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
library(dplyr)
library(ggmap)
library (leaflet)
library(readr)

scwa <- read_csv("scwa.csv")



shinyUI(fluidPage(
  
  leafletOutput("coolmap", width = "1900px", height = "950px")
  
  )
)